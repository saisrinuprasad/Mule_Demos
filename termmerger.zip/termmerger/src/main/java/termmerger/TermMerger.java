package termmerger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellCopyPolicy;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

public class TermMerger implements Callable{

	static XSSFSheet sheet = null;

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {

		try { 
			FileInputStream file = new FileInputStream(new File("C:\\geetu-proj\\CollibraExtract.xlsx")); 
			FileOutputStream fos = new FileOutputStream("C:\\geetu-proj\\CollibraExtract_out.xlsx");
			// Create Workbook instance holding reference to .xlsx file 
			XSSFWorkbook workbook = new XSSFWorkbook(file); 
			XSSFWorkbook writeWorkbook = new XSSFWorkbook(); 
		
			XSSFSheet sheetToWrite = writeWorkbook.createSheet("formated_data");
			// Get first/desired sheet from the workbook 
			sheet = workbook.getSheetAt(0); 

			// Iterate through each rows one by one 
			Iterator<Row> rowIterator = sheet.iterator(); 
			String combinedTermCell = null;
			List<Row> finalRows = new ArrayList<Row>();
			List<Row> relatedRows = new ArrayList<Row>();
			while (rowIterator.hasNext()) { 
				Row row = rowIterator.next(); 
				Cell termCell = row.getCell(1);
				if (combinedTermCell == null){
					combinedTermCell = termCell.getStringCellValue();
					relatedRows.add(row);
				}else if(combinedTermCell.equalsIgnoreCase(termCell.getStringCellValue())){
					relatedRows.add(row);
				} else {
					//Send the related rows to the method

					Row CombinedRow = formatRows(relatedRows);
					// add the row returned from the method to FinalRow arrayList
					finalRows.add(CombinedRow);
					printRow(CombinedRow);
					//reset the combined term cell 
					combinedTermCell = termCell.getStringCellValue();
					relatedRows = new ArrayList<Row>();
					relatedRows.add(row);
				}

				//	System.out.println("Term Cell is ::"+termCell.getStringCellValue()); 
			} 

			copyRowsToSheet(sheetToWrite, finalRows);
			writeWorkbook.write(fos);
			file.close(); 
		} 
		catch (Exception e) { 
			e.printStackTrace(); 
		} 
		return null;
	}

	private static Row formatRows(List<Row> rowList){
		Row combinedRow = rowList.get(0);

		for (Row row : rowList){
			int numOfCells = row.getPhysicalNumberOfCells();
			for(int i=0; i<numOfCells; i++){
				for (int j=0; j<numOfCells; j++){
					if (i ==j){
						String consolatedRow = combinedRow.getCell(j).getStringCellValue()+","+ row.getCell(i).getStringCellValue();
						consolatedRow = avoidDuplicateTerms(consolatedRow);
						combinedRow.getCell(j).setCellValue(consolatedRow);
					}
				}
			}
		}


		return combinedRow;
	}

	private static void printRow(Row combinedRow){


		Iterator<Cell> cellIterator = combinedRow.iterator();

		while (cellIterator.hasNext()) {

			Cell currentCell = cellIterator.next();
			//getCellTypeEnum shown as deprecated for version 3.15
			//getCellTypeEnum ill be renamed to getCellType starting from version 4.0
			if (currentCell.getCellTypeEnum() == CellType.STRING) {
				System.out.println(currentCell.getStringCellValue() + "--");
			} else if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
				System.out.println(currentCell.getNumericCellValue() + "--");
			}

		}

	}

	private static String  avoidDuplicateTerms(String consolatedTerm){
		Set<String> uniqueTerms = new HashSet<String>();
		StringTokenizer strTok = new StringTokenizer(consolatedTerm,",");
		String finalStream = null;
		while(strTok.hasMoreTokens()){
			uniqueTerms.add(strTok.nextToken());
		}
		for(String term : uniqueTerms){
			if(finalStream == null){
				finalStream = term;
			}else{
				finalStream = finalStream + "," + term;
			}
		}
		/*	if (finalStream.contains(",")){
			int lastIndex = finalStream.lastIndexOf(",");
			System.out.println("Last Index::"+lastIndex);
			finalStream = finalStream.substring(0, lastIndex);
			System.out.println("dup avoided string :"+finalStream);
		}*/
		//System.out.println("dup avoided string :"+finalStream);
		return finalStream;
	}

	private static void copyRowsToSheet(XSSFSheet sheetToWrite, List<Row> formatedRows){

		for(Row row : formatedRows){
			Row rowToWrite = sheetToWrite.createRow(row.getRowNum());
			Iterator<Cell> cellIterator = row.iterator();
			int cellNo=0;
			while(cellIterator.hasNext()){
				Cell cell =  rowToWrite.createCell(cellNo++);
				cell.setCellValue(cellIterator.next().getStringCellValue());
			}


		}
	}
}